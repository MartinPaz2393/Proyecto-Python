"""
Controlador.

Le pide cosas al modelo y se las pasa a la vista.
No calcula ni imprime. Si aqui aparece un print(), algo se hizo mal.
"""

import os

from app.modelo import ingesta
from app.vista import consola
from app.modelo import indicadores
from app.modelo.repositorio import Repositorio
from app.modelo import exportador


class Aplicacion:

    def __init__(self, ruta_csv, ruta_bd, carpeta_output):
        self.ruta_csv = ruta_csv
        self.carpeta_output = carpeta_output
        self.repositorio = Repositorio(ruta_bd)
        # TODO: crea el repositorio

    def cargar(self):
        """TODO: leer, validar, quitar duplicados, guardar, informar."""
        """
        Lee el CSV, elimina duplicados y guarda las operaciones.
        """

        if not os.path.exists(self.ruta_csv):
            print("No existe el archivo:", self.ruta_csv)
        
        try:
            registros, errores = ingesta.leer_csv(self.ruta_csv)

            print("Registros leidos:", len(registros))
            print("Registros rechazados:", len(errores))

            registros_unicos, duplicados = ingesta.quitar_duplicados(registros)

            print("Duplicados encontrados:", duplicados)

            insertados = self.repositorio.guardar(registros_unicos)

            print("Registros insertados en SQLite:", insertados)

            print("Carga finalizada correctamente.")

        except Exception as e:
            print("Error al cargar la informacion:", e)


    def ver_indicadores(self):
        """Calcula y muestra los indicadores de cobranzas."""

        # Obtenemos los registros desde SQLite
        registros = self.repositorio.listar()

        # Calculamos los indicadores
        resultado = indicadores.calcular(registros)
      
        # Mostramos los indicadores
        consola.mostrar_indicadores(resultado)


    def explorar(self):
        raise NotImplementedError

    def generar_entregable(self):

         # 1. Obtener operaciones desde SQLite
        registros = self.repositorio.listar()

        # 2. Generar archivo CSV
        ruta_archivo, cantidad = exportador.generar(registros, self.carpeta_output)

          # 3. Mostrar resultado
        consola.mostrar_entregable(ruta_archivo, cantidad)
    
    def ver_historial(self):
        raise NotImplementedError

    def ejecutar(self):
        acciones = {
            "1": self.cargar,
            "2": self.ver_indicadores,
            "3": self.explorar,
            "4": self.generar_entregable,
            "5": self.ver_historial,
        }
        while True:
            consola.mostrar_menu()
            opcion = consola.pedir_opcion()
            if opcion == "6":
                consola.mensaje("Fin del proceso.")
                return
            accion = acciones.get(opcion)
            if accion is None:
                consola.advertencia("Esa opcion no existe.")
            else:
                accion()
