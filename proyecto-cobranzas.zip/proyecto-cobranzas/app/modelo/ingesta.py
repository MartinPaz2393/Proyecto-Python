"""
Lectura y validacion del archivo del dia.

Regla que no se negocia: una fila mala nunca tumba la carga.
Se rechaza, se anota el motivo y se sigue con la siguiente.
"""

import csv


def leer_csv(ruta):
    """
    TODO: devuelve (registros_validos, errores).

    Cada error debe decir en que fila ocurrio y por que.

    Pista de la estructura:

        with open(ruta, encoding="utf-8") as archivo:
            lector = csv.DictReader(archivo)
            for numero, fila in enumerate(lector, start=2):
                try:
                    ...
                except ValueError as error:
                    errores.append({"fila": numero, "motivo": str(error)})
    """
    operaciones = []
    errores = []
    with open(ruta, encoding='utf-8') as file:
        lector = csv.DictReader(file)
        for numero, fila in enumerate(lector, start=2):
            try:
                operaciones.append(fila)

            except Exception as e:
                errores.append({"fila":numero,"motivo":str(e)})
        return operaciones, errores


def quitar_duplicados(deudas):
    """
    TODO: el CSV trae filas repetidas. Deja una sola por identificador.

    Devuelve (unicos, cantidad_descartada).
    """
    ids_deudas = {}
    duplicados = 0
    for deuda in deudas:
        actual_operacion = ids_deudas.get(deuda["id_operacion"])
        id_deuda = deuda["id_operacion"]
        if actual_operacion is None:
            ids_deudas[str(id_deuda)] = deuda
        else:
            duplicados += 1
            ids_deudas[deuda["id_operacion"]] = actual_operacion
    return list(ids_deudas.values()), duplicados



    
