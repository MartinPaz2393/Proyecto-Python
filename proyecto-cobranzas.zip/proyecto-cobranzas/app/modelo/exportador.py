"""
Generacion del entregable.

El final del flujo: el archivo que recibe la otra area.
Ponle la fecha en el nombre para que el de hoy no pise el de ayer.
"""

import os
from datetime import date

import pandas as pd


def generar(registros, carpeta_output):
    """
    TODO: escribe el archivo y devuelve (ruta, filas_escritas).

    Usa nombres de columna legibles para quien lo abra: "Saldo actual",
    no "saldo_actual". Quien recibe esto no programa.
    """
    # 1. Convertir los registros en un DataFrame
    df = pd.DataFrame(registros)

    # Si no hay registros, generar un archivo vacío
    if df.empty:
        os.makedirs(carpeta_output, exist_ok=True)
        ruta_archivo = os.path.join(carpeta_output,"cola_cobranzas.csv")
        df.to_csv(ruta_archivo, index=False, encoding="utf-8-sig")
        return ruta_archivo, 0

    # 2. Limpiar y convertir las fechas
    df["fecha_vencimiento"] = pd.to_datetime(df["fecha_vencimiento"],errors="coerce")

    df["fecha_pago"] = pd.to_datetime(df["fecha_pago"],errors="coerce")

    # 3. Convertir el monto a número
    df["monto_cuota"] = pd.to_numeric(df["monto_cuota"],errors="coerce").fillna(0)

    # 4. Convertir gestiones previas a número
    df["gestiones_previas"] = pd.to_numeric(df["gestiones_previas"],errors="coerce").fillna(0)

    # 5. Identificar operaciones pendientes
    pendientes = df[df["fecha_pago"].isna()].copy()

    # 6. Calcular días de mora
    hoy = pd.Timestamp.today().normalize()
    pendientes["dias_mora"] = (hoy - pendientes["fecha_vencimiento"]).dt.days

    # 7. Seleccionar únicamente operaciones vencidas
    vencidas = pendientes[pendientes["dias_mora"] > 0 ].copy()

     # 8. Puntaje por monto de deuda
    vencidas["puntaje_monto"] = 0

    vencidas.loc[ vencidas["monto_cuota"] < 500,"puntaje_monto"] = 5

    vencidas.loc[(vencidas["monto_cuota"] >= 500)&(vencidas["monto_cuota"] < 1000),"puntaje_monto"] = 10

    vencidas.loc[(vencidas["monto_cuota"] >= 1000)&(vencidas["monto_cuota"] < 2000), "puntaje_monto"] = 20

    vencidas.loc[(vencidas["monto_cuota"] >= 2000)&(vencidas["monto_cuota"] < 3000), "puntaje_monto"] = 30

    vencidas.loc[ vencidas["monto_cuota"] >= 3000,"puntaje_monto"] = 40

    # 9. Puntaje por días de mora
    vencidas["puntaje_mora"] = 0

    vencidas.loc[vencidas["dias_mora"] <= 30,"puntaje_mora"] = 5

    vencidas.loc[(vencidas["dias_mora"] > 30)&(vencidas["dias_mora"] <= 60),"puntaje_mora"] = 10

    vencidas.loc[(vencidas["dias_mora"] > 60)&(vencidas["dias_mora"] <= 90),"puntaje_mora"] = 20

    vencidas.loc[vencidas["dias_mora"] > 90,"puntaje_mora"] = 30

    # 10. Puntaje por promesa incumplida
    promesa = (vencidas["promesa_incumplida"].fillna("").astype(str).str.strip().str.upper())
    vencidas["puntaje_promesa"] = promesa.eq("SI") * 20

    # 11. Puntaje por gestiones previas
    vencidas["puntaje_gestiones"] = 0

    vencidas.loc[vencidas["gestiones_previas"] == 0,"puntaje_gestiones"] = 5

    vencidas.loc[(vencidas["gestiones_previas"] >= 1)& (vencidas["gestiones_previas"] <= 3),"puntaje_gestiones"] = 10

    # 12. Calcular puntaje total
    vencidas["puntaje_prioridad"] = (vencidas["puntaje_monto"] + vencidas["puntaje_mora"] + vencidas["puntaje_promesa"] + vencidas["puntaje_gestiones"])

    # 13. Clasificar prioridad
    vencidas["prioridad"] = "BAJA"

    vencidas.loc[vencidas["puntaje_prioridad"] >= 40,"prioridad"] = "MEDIA"

    vencidas.loc[vencidas["puntaje_prioridad"] >= 60,"prioridad"] = "ALTA"

    vencidas.loc[vencidas["puntaje_prioridad"] >= 80,"prioridad"] = "CRITICA"

    # 14. Ordenar por prioridad
    vencidas = vencidas.sort_values("puntaje_prioridad",ascending=False)

    # 15. Crear carpeta output
    os.makedirs(carpeta_output, exist_ok=True)

    # 16. Generar archivo CSV
    ruta_archivo = os.path.join(
        carpeta_output,
        "cola_cobranzas.csv"
    )

    vencidas.to_csv(
        ruta_archivo,
        index=False,
        encoding="utf-8-sig"
    )

    # 17. Devolver ruta y cantidad
    return ruta_archivo, len(vencidas)
