"""
Clases de dominio de TU tematica.

Aqui vive la regla de negocio. Si tu tematica es cobranzas, la clase se
llamara Deuda; si es inventario, Producto. El nombre importa: debe ser
la palabra que usa el area, no "Dato" ni "Registro".
"""


def a_decimal(texto):
    """Convierte texto a decimal. Acepta coma o punto."""
    if texto is None:
        raise ValueError("valor vacio")
    texto = str(texto).strip().replace(",", ".")
    if texto == "":
        raise ValueError("valor vacio")
    return float(texto)


def a_entero(texto):
    """Convierte texto a entero."""
    if texto is None:
        raise ValueError("valor vacio")
    texto = str(texto).strip()
    if texto == "":
        raise ValueError("valor vacio")
    return int(float(texto.replace(",", ".")))


class deudas:
    """
    TODO: renombra esta clase con el nombre real de tu entidad.

    Sus atributos son las columnas del CSV que generaste.
    """

    def __init__(self,id_operacion,documento_cliente,cliente,monto_cuota,fecha_vencimiento,fecha_pago,canal_preferido,gestiones_previas,promesa_incumplida):
        self.id_operacion = id_operacion
        self.documento_cliente = documento_cliente
        self.cliente = cliente
        self.monto_cuota = monto_cuota
        self.fecha_vencimiento = fecha_vencimiento
        self.fecha_pago = fecha_pago
        self.canal_preferido = canal_preferido
        self.gestiones_previas = gestiones_previas
        self.promesa_incumplida = promesa_incumplida

    @classmethod
    def desde_fila(cls, fila):
        """
        TODO: construye el objeto a partir de una fila del CSV.

        Si la fila no sirve, levanta ValueError explicando el motivo.
        Valida al menos: campos obligatorios, tipos y rangos imposibles
        (montos negativos, fechas futuras, etc.).
        """
        raise NotImplementedError

    def clasificar(self):
        """
        TODO: tu regla de negocio.

        Devuelve la categoria o el puntaje que tu area necesita:
        nivel de riesgo, prioridad de llamada, estado de stock...
        """
        raise NotImplementedError

    def como_diccionario(self):
        """
        TODO: devuelve los datos como diccionario.

        La vista NO debe recibir objetos del modelo.
        """
        raise NotImplementedError
