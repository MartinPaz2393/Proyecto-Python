"""
Persistencia en SQLite.

Dos tablas como minimo:
  - la de tu entidad, con su identificador como PRIMARY KEY
  - una tabla de cargas, para saber que dia se cargo que archivo

La segunda es la que impide cargar dos veces el mismo dia.

Advertencia de rendimiento: NO pongas commit() dentro del bucle de
insercion. Con 50 000 filas se vuelve de cientos a miles de veces mas
lento. Usa executemany() y un solo commit al final.
"""

import os
import sqlite3
import pandas as pd

COLUMNAS_OPERACIONES = [
    "id_operacion","documento_cliente","cliente","monto_cuota","fecha_vencimiento","fecha_pago","canal_preferido","gestiones_previas","promesa_incumplida"
    ]


ESQUEMA = """
CREATE TABLE IF NOT EXISTS operaciones (
    id_operacion TEXT PRIMARY KEY,
    documento_cliente TEXT NOT NULL,
    cliente TEXT,
    monto_cuota REAL,
    fecha_vencimiento TEXT,
    fecha_pago TEXT,
    canal_preferido TEXT,
    gestiones_previas TEXT,
    promesa_incumplida TEXT
);
"""


class CargaDuplicada(Exception):
    """Se intento cargar el mismo archivo dos veces el mismo dia."""


class Repositorio:

    def __init__(self, ruta_bd):
        # TODO: crea la carpeta si no existe, conecta y ejecuta el esquema
        carpeta_ubicacion = os.path.dirname(ruta_bd)
        if carpeta_ubicacion and not os.path.exists(carpeta_ubicacion):
            os.makedirs(carpeta_ubicacion)
        self.ruta_bd = ruta_bd
        self.conexion = sqlite3.connect(ruta_bd)
        self.cursor = self.conexion.cursor()
        self.conexion.executescript(ESQUEMA)
        self.conexion.commit()

    #def guardar_operaciones(self,operaciones:list[Operaciones]):
     #   registros = pd.DataFrame()


    def guardar_operaciones():
        pass

    def guardar(self, registros, forzar=False, archivo=""):
        """TODO: inserta con executemany() y un solo commit."""
        """
        Guarda las operaciones en SQLite.
        Devuelve la cantidad de operaciones insertadas.
        """

        consulta = """
        INSERT OR IGNORE INTO operaciones (
            id_operacion,
            documento_cliente,
            cliente,
            monto_cuota,
            fecha_vencimiento,
            fecha_pago,
            canal_preferido,
            gestiones_previas,
            promesa_incumplida
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """

        datos = []

        for registro in registros:
            datos.append((
            registro["id_operacion"],
            registro["documento_cliente"],
            registro["cliente"],
            registro["monto_cuota"],
            registro["fecha_vencimiento"],
            registro["fecha_pago"],
            registro["canal_preferido"],
            registro["gestiones_previas"],
            registro["promesa_incumplida"]))

            cambios_antes = self.conexion.total_changes

        self.cursor.executemany(consulta, datos)

        self.conexion.commit()

        cambios_despues = self.conexion.total_changes

        insertados = cambios_despues - cambios_antes

        return insertados

    def ya_se_cargo_hoy(self, archivo):
        """TODO: consulta la tabla de cargas."""
        raise NotImplementedError

    def registrar_carga(self, archivo, validos, rechazados):
        raise NotImplementedError

    def historial(self, limite=15):
        raise NotImplementedError

    def contar(self):
        raise NotImplementedError

    def listar(self):
        """TODO: devuelve la data como lista de diccionarios."""
        """
    Obtiene todas las operaciones de la base de datos.
    Devuelve una lista de diccionarios.
    """

        self.cursor.execute("""
            SELECT
            id_operacion,
            documento_cliente,
            cliente,
            monto_cuota,
            fecha_vencimiento,
            fecha_pago,
            canal_preferido,
            gestiones_previas,
            promesa_incumplida
            FROM operaciones
            """)

        filas = self.cursor.fetchall()

        columnas = [
        "id_operacion",
        "documento_cliente",
        "cliente",
        "monto_cuota",
        "fecha_vencimiento",
        "fecha_pago",
        "canal_preferido",
        "gestiones_previas",
        "promesa_incumplida"
        ]

        registros = []

        for fila in filas:
            registro = dict(zip(columnas, fila))
            registros.append(registro)

        return registros

    def cerrar(self):
            self.conexion.close()