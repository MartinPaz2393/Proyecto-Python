"""
Calculo de indicadores con pandas.

Regla: el DataFrame NO sale de este archivo. Hacia afuera se devuelven
listas y diccionarios, para que la vista no sepa que pandas existe.

Revisa TEMATICAS.md: ahi estan los indicadores minimos de tu tema.
"""

import pandas as pd


def calcular(registros):
    """
    TODO: devuelve un diccionario con los indicadores de tu tematica.

    Pista: pd.DataFrame(registros) y de ahi groupby().agg().
    Devuelve numeros de Python (int(), float()), no tipos de numpy.
    """
   
    """
    Calcula indicadores basicos de cobranzas.
    Devuelve un diccionario con los resultados.
    """
     # 1. Convertimos los registros en un DataFrame
    df = pd.DataFrame(registros)

    # 2. Convertimos las fechas a datetime  
    df["fecha_vencimiento"] = pd.to_datetime(df["fecha_vencimiento"],errors="coerce")
    df["fecha_pago"] = pd.to_datetime(df["fecha_pago"],errors="coerce")

    # Convertimos monto_cuota a texto para limpiar sus valores
    df["monto_cuota"] = df["monto_cuota"].astype(str).str.strip()

    # Eliminamos espacios y símbolos monetarios
    df["monto_cuota"] = df["monto_cuota"].str.replace(r"[^\d,.-]","", regex=True)

    # Corregimos separadores decimales
    def limpiar_monto(valor):
        if "," in valor and "." in valor:
            valor = valor.replace(",","")
        elif "," in valor:
            valor = valor.replace(",",".")
        return valor

    df["monto_cuota"] = df["monto_cuota"].apply(limpiar_monto)

    # Convertimos los valores a números
    df["monto_cuota"] = pd.to_numeric(df["monto_cuota"],errors="coerce")

    # Los valores que no pudieron convertirse quedan como 0
    df["monto_cuota"] = df["monto_cuota"].fillna(0)

    # 3. Identificamos operaciones pendientes de pago
    pendientes = df[df["fecha_pago"].isna()].copy()

    # 4. Calculamos los dias de mora
    hoy = pd.Timestamp.today().normalize()
    pendientes["dias_mora"] = (hoy - pendientes["fecha_vencimiento"]).dt.days

    # 5. Conservamos solamente las operaciones vencidas
    vencidas = pendientes[pendientes["dias_mora"] > 0].copy()

    # 6. Clasificamos la deuda por antiguedad
    vencidas["antiguedad"] = pd.cut(
        vencidas["dias_mora"],
        bins=[0, 30, 60, 90, float("inf")],
        labels=["1-30", "31-60", "61-90", "Mas de 90"]
    )

    # 7. Agrupamos y calculamos indicadores
    resumen = vencidas.groupby("antiguedad", observed=False).agg(
        total_deuda=("monto_cuota", "sum"),
        cantidad_operaciones=("id_operacion", "count")
    )

    # 8. Obtenemos el total pendiente
    total_pendiente = pendientes["monto_cuota"].sum()

    # 9. Obtenemos el total vencido
    total_vencido = vencidas["monto_cuota"].sum()

    # 10. Devolvemos los indicadores
    return {
        "total_pendiente": float(total_pendiente),
        "cantidad_pendiente": int(len(pendientes)),
        "total_vencido": float(total_vencido),
        "deuda_1_30": float(resumen.loc["1-30", "total_deuda"]),
        "deuda_31_60": float(resumen.loc["31-60", "total_deuda"]),
        "deuda_61_90": float(resumen.loc["61-90", "total_deuda"]),
        "deuda_mas_90": float(resumen.loc["Mas de 90", "total_deuda"])
    }
